# @barchart/aws-lambda-pdf-generator <small>3.0.1</small>

> Serverless application that coverts HTML to PDF

[Quick Start](/content/quick_start)
